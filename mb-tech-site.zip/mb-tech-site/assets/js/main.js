/* M B TECH — scripts du site (vanilla JS, aucune dépendance) */
(function () {
  "use strict";
  document.documentElement.classList.remove("no-js");
  var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* --- Menu mobile --- */
  var nav = document.querySelector(".nav");
  var toggle = document.querySelector(".nav__toggle");
  if (nav && toggle) {
    toggle.addEventListener("click", function () {
      var open = nav.classList.toggle("is-open");
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
      toggle.setAttribute("aria-label", open ? "Fermer le menu" : "Ouvrir le menu");
    });
    nav.querySelectorAll(".nav__links a").forEach(function (a) {
      a.addEventListener("click", function () {
        nav.classList.remove("is-open");
        toggle.setAttribute("aria-expanded", "false");
      });
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && nav.classList.contains("is-open")) {
        nav.classList.remove("is-open");
        toggle.setAttribute("aria-expanded", "false");
        toggle.focus();
      }
    });
  }

  /* --- Apparition au défilement --- */
  var items = document.querySelectorAll(".reveal");
  if (!reduce && "IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add("is-in"); io.unobserve(en.target); }
      });
    }, { rootMargin: "0px 0px -8% 0px", threshold: 0.08 });
    items.forEach(function (el, i) {
      el.style.transitionDelay = (el.dataset.delay || 0) + "ms";
      io.observe(el);
    });
  } else {
    items.forEach(function (el) { el.classList.add("is-in"); });
  }


  /* --- Vidéos : pause hors écran, arrêt si l'utilisateur limite les animations --- */
  var vids = document.querySelectorAll("video");
  vids.forEach(function (v) {
    v.muted = true;
    if (reduce) { v.removeAttribute("autoplay"); v.pause(); return; }
    if ("IntersectionObserver" in window) {
      new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          if (en.isIntersecting) { var p = v.play(); if (p && p.catch) p.catch(function () {}); } else { v.pause(); }
        });
      }, { threshold: 0.1 }).observe(v);
    }
  });

  /* --- Fond du hero : réseau de nœuds (canvas, si présent) --- */
  var canvas = document.querySelector(".hero__bg");
  if (canvas && canvas.getContext) {
    var ctx = canvas.getContext("2d");
    var nodes = [], w = 0, h = 0, dpr = Math.min(window.devicePixelRatio || 1, 2), raf = null;
    function resize() {
      var r = canvas.getBoundingClientRect();
      w = r.width; h = r.height;
      canvas.width = w * dpr; canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var count = Math.round(Math.min(70, (w * h) / 18000));
      nodes = [];
      for (var i = 0; i < count; i++) {
        nodes.push({ x: Math.random() * w, y: Math.random() * h, vx: (Math.random() - 0.5) * 0.25, vy: (Math.random() - 0.5) * 0.25, hot: Math.random() < 0.08 });
      }
    }
    function draw() {
      ctx.clearRect(0, 0, w, h);
      for (var i = 0; i < nodes.length; i++) {
        var a = nodes[i];
        if (!reduce) {
          a.x += a.vx; a.y += a.vy;
          if (a.x < 0 || a.x > w) a.vx *= -1;
          if (a.y < 0 || a.y > h) a.vy *= -1;
        }
        for (var j = i + 1; j < nodes.length; j++) {
          var b = nodes[j], dx = a.x - b.x, dy = a.y - b.y, d = dx * dx + dy * dy;
          if (d < 19000) {
            ctx.strokeStyle = "rgba(102,155,188," + (0.22 * (1 - d / 19000)).toFixed(3) + ")";
            ctx.lineWidth = 1;
            ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
          }
        }
      }
      for (var k = 0; k < nodes.length; k++) {
        var n = nodes[k];
        ctx.fillStyle = n.hot ? "#c1121f" : "rgba(156,193,216,0.7)";
        ctx.beginPath(); ctx.arc(n.x, n.y, n.hot ? 2.6 : 1.6, 0, Math.PI * 2); ctx.fill();
      }
      if (!reduce) raf = requestAnimationFrame(draw);
    }
    resize(); draw();
    window.addEventListener("resize", function () { cancelAnimationFrame(raf); resize(); draw(); });
    document.addEventListener("visibilitychange", function () {
      if (document.hidden) cancelAnimationFrame(raf); else if (!reduce) { cancelAnimationFrame(raf); draw(); }
    });
  }

  /* --- Terminal : affichage ligne par ligne --- */
  var term = document.querySelector("[data-typed]");
  if (term && !reduce) {
    var lines = Array.prototype.slice.call(term.children);
    lines.forEach(function (l) { l.style.opacity = "0"; });
    lines.forEach(function (l, i) {
      setTimeout(function () { l.style.transition = "opacity .25s"; l.style.opacity = "1"; }, 500 + i * 260);
    });
  }

  /* --- Filtre des projets --- */
  var filters = document.querySelectorAll(".filter");
  if (filters.length) {
    filters.forEach(function (btn) {
      btn.addEventListener("click", function () {
        var f = btn.dataset.filter;
        filters.forEach(function (b) { b.setAttribute("aria-pressed", b === btn ? "true" : "false"); });
        document.querySelectorAll(".project").forEach(function (p) {
          p.hidden = !(f === "all" || (p.dataset.domain || "").split(" ").indexOf(f) !== -1);
        });
      });
    });
  }

  /* --- Formulaire de contact : ouvre le client e-mail (site statique) ---
     Pour un envoi serveur, remplacer par un POST vers votre endpoint (ex. Drogon). */
  var form = document.querySelector("#contact-form");
  if (form) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      if (!form.reportValidity()) return;
      var d = new FormData(form);
      var subject = "[Site] " + d.get("type") + " — " + d.get("company");
      var body =
        "Nom : " + d.get("name") + "\n" +
        "Entreprise : " + d.get("company") + "\n" +
        "Fonction : " + d.get("role") + "\n" +
        "E-mail : " + d.get("email") + "\n" +
        "Type de projet : " + d.get("type") + "\n\n" +
        d.get("message");
      window.location.href = "mailto:" + form.dataset.to + "?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(body);
      var status = form.querySelector(".form__status");
      if (status) status.textContent = "Votre messagerie s'ouvre avec la demande pré-remplie. Nous répondons sous 24 h ouvrées.";
    });
  }
})();
